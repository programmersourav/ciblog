<?php 

/**
 * User Model
 */
class Usermodel extends CI_Model
{

	public function articleList()
	{
		$query=$this->db->select('*')
						->from('articles')
						->join('users', 'users.id = articles.user_id')
						->get();

		return $query->result();	
	}

}

?>