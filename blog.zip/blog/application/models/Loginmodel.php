<?php 

/**
 * Login Model
 */
class Loginmodel extends CI_Model
{
	
	public function isvalidate($username,$password)
	{
		$condition = array('username' => $username, 'password' => $password);

		$query=$this->db->where($condition)->get('users');

		if($query->num_rows())
		{
			return $query->row()->id;
		}
		else
		{
			return false;
		}	
	}

	public function add_articles($array)
  	{
     	return $this->db->insert('articles',$array);
  	}

  	public function find_art($id)
  	{
  		$query=$this->db->where(['id'=>$id])->get('articles');
  		return $query->row();
  	}

  	public function edit_articles($articleid,$array)
  	{
  		return $this->db->update('articles', $array, "id = $articleid");
  	}

  	public function add_user($array)
  	{
     	return $this->db->insert('users',$array);
  	}

	public function articleList()
	{
		$id=$this->session->userdata('id');
		$query=$this->db->where(['user_id'=>$id])->get('articles');
		return $query->result();	
	}

	public function del_art($id)
	{
		return $this->db->delete('articles', array('id' => $id));
	}
}

?>