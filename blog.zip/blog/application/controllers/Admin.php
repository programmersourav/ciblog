<?php

/**
 * Admin Controller
 */
class Admin extends MY_controller
{

  public function __construct()
  {
    parent::__construct();
    if(!$this->session->userdata('id') )
    return redirect('login');
    
  }

	public function welcome()
	{ 
		$this->load->model('loginmodel');
		$articles=$this->loginmodel->articleList();
		$this->load->view('Admin/dashboard',['articles'=>$articles]);
	}

	public function adduser()
	{
		$this->load->view('Admin/Add_article');
	}


  public function delart($id)
  {
      $this->load->model('loginmodel','delete_article');
      if($this->delete_article->del_art($id))
      {
          $this->session->set_flashdata('msg','Articles deleted successfully');
          $this->session->set_flashdata('msg_class','alert-success');
      }
      else
      {
          $this->session->set_flashdata('msg','Articles not added Please try again!!');
          $this->session->set_flashdata('msg_class','alert-danger');
      }
      return redirect('admin/welcome');
  }


  public function editart($id)
  {
    $this->load->model('loginmodel','find_article');
    $article=$this->find_article->find_art($id);
    $this->load->view('Admin/Update',['article'=>$article]);
  }


  public function updatearticle($articleid)
  {

      $config=['upload_path' => './uploads/',
               'allowed_types' => 'gif|jpg|png'];

      $this->load->library('upload', $config); 

      if($this->form_validation->run('add_article_rules'))
      {

          $post=$this->input->post(); 
          if ($this->upload->do_upload('image_path')) {
              $data=$this->upload->data();
              $post['image_path']=$data['file_name'];
          }
          $this->load->model('loginmodel','article_edit');
          if($this->article_edit->edit_articles($articleid,$post))
          {
              $this->session->set_flashdata('msg','Articles Updated successfully');
              $this->session->set_flashdata('msg_class','alert-success');
          }
          else
          {
             $this->session->set_flashdata('msg','Articles not Updated Please try again!!');
             $this->session->set_flashdata('msg_class','alert-danger');
          }
          return redirect('admin/welcome');
      }
      else
      {   
          //$upload_error=$this->upload->display_errors();
          //echo $upload_error; exit;
          $this->editart($articleid);
      }
  }

  public function userValidation()
  {    
      $config=['upload_path' => './uploads/',
               'allowed_types' => 'gif|jpg|png'];

      $this->load->library('upload', $config);         

      if($this->form_validation->run('add_article_rules') && $this->upload->do_upload('userfile'))
      {

          $post=$this->input->post(); 
          $data=$this->upload->data();
          $post['image_path']=$data['file_name'];
          $this->load->model('loginmodel','article_add');
          if($this->article_add->add_articles($post))
          {
              $this->session->set_flashdata('msg','Articles added successfully');
              $this->session->set_flashdata('msg_class','alert-success');
          }
          else
          {
             $this->session->set_flashdata('msg','Articles not added Please try again!!');
             $this->session->set_flashdata('msg_class','alert-danger');
          }
          return redirect('Admin/welcome');
      }
      else
      {
          $upload_error=$this->upload->display_errors();
          $this->load->view('Admin/Add_article',['upload_error'=>$upload_error]);
      }

  }

  

   public function logout()
   {
    $this->session->unset_userdata('id');
    return redirect('login');
  }

}


?>

