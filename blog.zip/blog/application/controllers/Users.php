<?php

/**
 * 
 */
class Users extends MY_controller
{
	function __construct()
	{
    	parent::__construct();
    	$this->load->model('Usermodel');
	}
	
	public function index()
	{
		$articles=$this->Usermodel->articleList();
		//echo "<pre>"; print_r($articles); exit;
		$this->load->view('Users/articlelist',['articles'=>$articles]);
	}

	public function register()
    {
        $this->load->view('Admin/register'); 
    }
}


?>