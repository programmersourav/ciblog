<?php

/**
 * 
 */
class MY_controller extends CI_Controller
{
	
	
}

?>