
<?php include ('header.php'); ?>
<div class="container" style="margin-top:50px;">

<h1><small>RECENT POSTS</small></h1>
<?php if(count($articles)){ ?>
<?php foreach ($articles as $art) { ?>
<div class="container">
<div class="row">
      <?php
      		$date = new DateTime($art->post_time);
      		$filterDate = $date->format('F d, Y');
      ?>
      <hr>
      <div class="col-md-6">
      	<img class="user-img" src="<?php echo base_url('/')."uploads/".$art->image_path ?>">
	  </div>
   		<div class="col-md-6">
      <h2 class="article-title"><?= $art->article_title; ?></h2>
      <h5 class="article-time"><i class="fa fa-clock-o" aria-hidden="true"></i>
 Post by <?= $art->fname;  ?>, <?php echo $filterDate; ?>.</h5>
      <br>
      <div class="article-body">
      		<?= $art->article_body; ?>
      </div>
      </div>
</div>
      <br><br>
</div>
</div>
<?php 
	}
} 
else 
echo "<p>No data available.</p>";
  ?>
</div>
<?php include ('footer.php'); ?>