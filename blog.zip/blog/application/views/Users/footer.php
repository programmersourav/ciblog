<div class="container">
  © <?php date('Y') ?> Copyright: <a href="www.youtube.com/examaasaanhai"> ExamAasaanHai </a>
</div>
</body>

<script
  src="http://code.jquery.com/jquery-3.3.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

</html>