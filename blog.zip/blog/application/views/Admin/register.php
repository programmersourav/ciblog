<?php include('header.php'); ?>

<div class="container" style="margin-top:20px;">
<h1>Register Form</h1>


<div class="row">
<div class="col-lg-6">

</div>
</div>

<div class="container" style="margin-top:50px;">
<?php  if($msg=$this->session->flashdata('user')): 
$msg_class=$this->session->flashdata('user_class')
 ?>
<div class="row">
<div class="alert <?= $msg_class ?>">
<?= $msg; ?>
</div>
</div>
<?php endif; ?>
</div>


 <?php echo form_open('login/sendemail'); ?>
 <div class="row">
 <div class="col-lg-6">
  <div class="form-group">
    <label for="Username">Username:</label>
   <?php echo form_input(['class'=>'form-control','placeholder'=>'Enter Username','name'=>'username','value'=>set_value('username')]);  ?>
  </div>
  </div>
  <div class="col-lg-6" style="margin-top:40px;">
   <?php  echo form_error('username');  ?>
  </div>
  </div>
 <div class="row">
 <div class="col-lg-6">
  <div class="form-group">
    <label for="pwd">Password:</label>
  
   <?php  echo form_password(['class'=>'form-control','type'=>'password','placeholder'=>'Enter Password','name'=>'password','value'=>set_value('password')]); ?>
   </div>
   </div>
   <div class="col-lg-6" style="margin-top:40px;">
   <?php  echo form_error('password');  ?>
  </div>
   </div>
   <div class="row">
 <div class="col-lg-6">
  <div class="form-group">
    <label for="First name">First Name:</label>
   <?php echo form_input(['class'=>'form-control','placeholder'=>'Enter First Name','name'=>'fname','value'=>set_value('fname')]);  ?>
  </div>
  </div>
  <div class="col-lg-6" style="margin-top:40px;">
   <?php  echo form_error('fname');  ?>
  </div>
  </div>
   <div class="row">
 <div class="col-lg-6">
  <div class="form-group">
    <label for="last name">Last Name:</label>
   <?php echo form_input(['class'=>'form-control','placeholder'=>'Enter Last Name','name'=>'lname','value'=>set_value('lname')]);  ?>
  </div>
  </div>
  <div class="col-lg-6" style="margin-top:40px;">
   <?php  echo form_error('lname');  ?>
  </div>
  </div>
   <div class="row">
 <div class="col-lg-6">
  <div class="form-group">
    <label for="Username">Email:</label>
   <?php echo form_input(['class'=>'form-control','placeholder'=>'Enter Email','name'=>'email','value'=>set_value('email')]);  ?>
  </div>
  </div>
  <div class="col-lg-6" style="margin-top:40px;">
   <?php  echo form_error('email');  ?>
  </div>
  </div>
  <?php  echo form_submit(['type'=>'submit','class'=>'btn btn-primary','value'=>'Submit']);  ?>
  <?php  echo form_reset(['type'=>'reset','class'=>'btn btn-outline-secondary','value'=>'Reset']);  ?>
  Already Registered? <?php echo anchor('login', 'Login', 'class="btn btn-sm btn-info"'); ?> here.
 
</div>

<?php include('footer.php'); ?>