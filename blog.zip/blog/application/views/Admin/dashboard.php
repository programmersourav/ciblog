
<?php include ('header.php'); ?>
<div class="container" style="margin-top:50px;"">
<div class="row">
<?=   anchor('admin/adduser','Add Articles',['class'=>'btn btn-lg btn-primary'])  ?>
</div>
<div class="container" style="margin-top: 50px;">

<div class="container" style="margin-top:50px;">
<?php  if($msg=$this->session->flashdata('msg')): 
$msg_class=$this->session->flashdata('msg_class')
 ?>
<div class="row">
<div class="alert <?= $msg_class ?>">
<?= $msg; ?>
</div>
</div>
<?php endif; ?>
</div>

<div class="table">
		<table>
			<thead>
				<tr>
					<th>ID</th>
					<th>Image</th>
					<th>Article Title</th>
					<th>Article Body</th>
					<th>Edit</th>
					<th>Delete</th>
				</tr>
			</thead>
			<tbody>	
			<?php if(count($articles)){ $count=1; ?>	
			<?php foreach ($articles as $art) { ?>
				<tr>
					<td><?= $count ?></td>
					<td><img class="dashboard-img" src="<?php echo base_url('/')."uploads/".$art->image_path ?>"></td>
					<td><?= $art->article_title; ?></td>
					<td><?= $art->article_body; ?></td>
					<td><?=  anchor("admin/editart/{$art->id}",'Edit',['class'=>'btn btn-primary']);  ?></td>
					<td><?=  anchor("admin/delart/{$art->id}",'Delete',['class'=>'btn btn-danger']);  ?></td>
				</tr>
			<?php 
			$count++;	}
			} else{ ?>	
				
				<tr colspan="3">
				<td colspan="3">No data available</td>
				</tr>
			<?php } ?>	
			</tbody>
		</table>

</div>

<?php include ('footer.php'); ?>