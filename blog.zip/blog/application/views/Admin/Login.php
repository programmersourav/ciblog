<!DOCTYPE html>
<?php include ('header.php'); ?>


<div class=container style="margin-top: 20px;">
	<h1>Admin Form</h1>

<?php  if($error=$this->session->flashdata('Login_failed')):  ?>
<div class="row">
<div class="col-lg-6">
<div class="alert alert-danger">
<?= $error; ?>
</div>
</div>
</div>
<?php endif; ?>
	
<?php echo form_open('login'); ?>
<div class="row">
	<div class="col-md-6">
		<div class="form-group">
			<?php echo form_label('Username:', 'username'); ?>
			<?php echo form_input(['class'=>'form-control','placeholder'=>'Enter Username','name'=>'uname','value'=>set_value('uname')]); ?>
		</div>
	</div>
	<div class="col-md-6">
		<?php echo form_error('uname','<div class="text-danger error">', '</div>') ?>
	</div>	
	<div class="col-md-6">	
		<div class="form-group">
			<?php echo form_label('Password:', 'psw'); ?>
			<?php echo form_password(['class'=>'form-control','placeholder'=>'Enter Password','name'=>'pass','value'=>set_value('pass')]); ?>
		</div>
	</div>
	<div class="col-md-6">
		<?php echo form_error('pass','<div class="text-danger error">', '</div>') ?>
	</div>	
	
		<div class="col-md-1">
			<?php echo form_submit(['type'=>'submit','class'=>'btn btn-primary','value'=>'Submit']); ?>
		</div>
		<div class="col-md-1 reset">	
			<?php echo form_reset(['type'=>'reset','class'=>'btn btn-secondary','value'=>'Reset']); ?>
		</div>
		<div class="col-md-1 reset">	
			<?php echo anchor('users/register', 'Sign up?', 'class="link-class"'); ?>
		</div>	
	
</div>	
</form>
</div>

<?php include ('footer.php'); ?>