<html>
<head>
	<title>Article List</title>
	<!-- <link rel="stylesheet" type="text/css" href="<?= base_url("Assets/css/bootstrap.min.css") ?>"> -->
	<?= link_tag("https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"); ?>
	<?= link_tag("https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"); ?>
  <?= link_tag("Assets/css/style.css"); ?>
</head>

<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <a class="navbar-brand" href="<?=  base_url('admin/welcome'); ?>">Admin Pannel</a>
  <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav">
            <li class="nav-item dropdown">
  				<li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" id="themes" style="font-size: 25px;">Menu <span class="caret"></span></a>
	              <div class="dropdown-menu" aria-labelledby="themes">
	                <a class="dropdown-item" target = "_blank" href="<?= base_url(); ?>">Visit Site</a>
	              </div>
    			</li>
    		</li>
    	<ul>
   </div>
 	<?php
   	if($this->session->userdata('id')){
   	?>
		<a href="<?=  base_url('admin/logout'); ?>" class="btn btn-danger" style="">Logout</a>
	<?php
	}
	  ?> 
</nav>