<div class="container">
  © <?php echo date("Y") ?> Copyright: <a href="www.youtube.com/examaasaanhai"> ExamAasaanHai </a>
</div>
</body>

<script src="http://code.jquery.com/jquery-3.3.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

<script>	
	function readURL(input) {
		  if (input.files && input.files[0]) {
		    var reader = new FileReader();

		    reader.onload = function(e) {
		      $('#blah').attr('src', e.target.result);
		    }
		    reader.readAsDataURL(input.files[0]);
		  }
	}

	$("#imgInp").change(function(){
	  readURL(this);
	});

	$(document).on('click', '.browse', function(){
	  var file = $(this).parent().parent().parent().find('.file');
	  file.trigger('click');
	});
	$(document).on('change', '.file', function(){
	  $(this).parent().find('.form-control').val($(this).val().replace(/C:\\fakepath\\/i, ''));
	});
</script>

</html>